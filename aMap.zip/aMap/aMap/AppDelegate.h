//
//  AppDelegate.h
//  aMap
//
//  Created by iosOne on 16/7/31.
//  Copyright © 2016年 吕盼举. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

