//
//  MyLocationManager.m
//  aMap
//
//  Created by iosOne on 16/7/31.
//  Copyright © 2016年 吕盼举. All rights reserved.
//

#import "MyLocationManager.h"
#import <AMapLocationKit/AMapLocationKit.h>

#define aMapKey cf8da1a7aac756748e9845149fd5f1a5

static MyLocationManager *LM = nil;

@interface MyLocationManager ()<AMapLocationManagerDelegate>

@property(nonatomic,strong)AMapLocationManager *locationManager;

@end

@implementation MyLocationManager


+(instancetype)sharedInstance
{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        LM = [[self alloc]init];
    });
    return LM;
}

-(AMapLocationManager *)locationManager
{
    if (!_locationManager)
    {
        _locationManager = [[AMapLocationManager alloc] init];
    }
    return _locationManager;
}

//开启持续定位
-(void)startstartUpdatingLocation
{
    //设置允许后台定位参数，保持不会被系统挂起
    self.locationManager.delegate = self;
    [self.locationManager setPausesLocationUpdatesAutomatically:NO];
    [self.locationManager setAllowsBackgroundLocationUpdates:YES];//iOS9(含)以上系统需设置
    [self.locationManager startUpdatingLocation];
}

//停止持续定位
-(void)stopUpdatingLocation
{
    [self.locationManager stopUpdatingLocation];
}

#pragma mark - AMapLocationManagerDelegate
- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location
{
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
}

//一次精准定位
-(void)requestLocationOnce
{
    // 带逆地理信息的一次定位（返回坐标和地址信息）
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    //   定位超时时间，最低2s，此处设置为11s
    self.locationManager.locationTimeout =11;
    //   逆地理请求超时时间，最低2s，此处设置为12s
    self.locationManager.reGeocodeTimeout = 12;
    // 带逆地理（返回坐标和地址信息）。将下面代码中的YES改成NO，则不会返回地址信息。
    [self.locationManager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
        if (error)
        {
            NSLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
            if (error.code == AMapLocationErrorLocateFailed)
            {
                return;
            }
        }
        NSLog(@"location:%@", location);
        if (regeocode)
        {
            NSLog(@"reGeocode:%@", regeocode);
        }
    }];
}

@end
