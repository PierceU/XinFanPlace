//
//  MyLocationManager.h
//  aMap
//
//  Created by iosOne on 16/7/31.
//  Copyright © 2016年 吕盼举. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyLocationManager : NSObject

+(instancetype)sharedInstance;
-(void)startstartUpdatingLocation;
-(void)stopUpdatingLocation;
-(void)requestLocationOnce;
@end
